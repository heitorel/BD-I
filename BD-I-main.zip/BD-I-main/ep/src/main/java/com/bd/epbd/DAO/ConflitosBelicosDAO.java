package com.bd.epbd.DAO;

import com.bd.epbd.ConexaoMySQL;
import com.bd.epbd.bean.ConflitoBelico;
import com.bd.epbd.bean.Divisao;
import com.bd.epbd.bean.PaisesConflitos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ConflitosBelicosDAO {

    public ConflitosBelicosDAO() {
    }
    ConexaoMySQL con = new ConexaoMySQL();

    public List<ConflitoBelico> listaConflitosMaisMortes () throws SQLException, ClassNotFoundException{
        Connection connection = con.getConnection();

        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<ConflitoBelico> conflitosMaisMortes = new ArrayList<>();

        try{
            stmt = connection.prepareStatement("QUERY");
            rs = stmt.executeQuery();

            while(rs.next()){
                ConflitoBelico conflitoBelico = new ConflitoBelico();

                conflitoBelico.setNome(rs.getString("nome"));
                conflitoBelico.setMortos(rs.getInt("quantidade"));
                conflitosMaisMortes.add(conflitoBelico);
            }

        }catch(SQLException ex){
            Logger.getLogger(ConflitosBelicosDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        con.FecharConexao();
        return conflitosMaisMortes;
    }

    public List<PaisesConflitos> listaPaisesMaisConflitosReligiosos () throws SQLException, ClassNotFoundException{
        Connection connection = con.getConnection();

        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<PaisesConflitos> paisesConflitos = new ArrayList<>();

        try{
            stmt = connection.prepareStatement("QUERY");
            rs = stmt.executeQuery();

            while(rs.next()){
                PaisesConflitos paisConflito = new PaisesConflitos();

                paisConflito.setNome(rs.getString("nome"));
                paisConflito.setQuantidade(rs.getInt("quantidade"));
                paisesConflitos.add(paisConflito);
            }

        }catch(SQLException ex){
            Logger.getLogger(ConflitosBelicosDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        con.FecharConexao();
        return paisesConflitos;
    }

    public void CadastraConflito(String id, String nome, Integer mortos, Integer feridos, String tipo, Integer idGrupo)
            throws SQLException, ClassNotFoundException{

        Connection connection = con.getConnection();

        PreparedStatement stmt = null;

        ConflitoBelico conflitoBelico = new ConflitoBelico(id,nome,mortos,feridos,tipo,idGrupo);

        try{
            stmt = connection.prepareStatement("INSERT INTO CONFLITO VALUES (?,?,?,?,?,?)");

            stmt.setString(1, conflitoBelico.getId());
            stmt.executeUpdate();

        }catch(SQLException ex){
            Logger.getLogger(ConflitosBelicosDAO.class.getName()).log(Level.SEVERE, null, ex);

        } finally{
            con.FecharConexao();

        }

    }
}
