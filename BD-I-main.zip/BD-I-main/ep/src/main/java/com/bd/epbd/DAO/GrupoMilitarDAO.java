package com.bd.epbd.DAO;

import com.bd.epbd.ConexaoMySQL;
import com.bd.epbd.bean.GrupoMilitar;
import com.bd.epbd.bean.LiderPolitico;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

public class GrupoMilitarDAO {

    public GrupoMilitarDAO() {
    }
    ConexaoMySQL con = new ConexaoMySQL();

    public void CadastraLiderPolitco(String id, String conflitos, String nome, Date dataSaida, Date dataEntrada)
            throws SQLException, ClassNotFoundException{

        Connection connection = con.getConnection();

        PreparedStatement stmt = null;

        GrupoMilitar grupoMilitar = new GrupoMilitar(id,conflitos,nome,dataSaida,dataEntrada);

        try{
            stmt = connection.prepareStatement("INSERT INTO LIDER_POLITICO VALUES (?,?,?,?,?)");

            stmt.setString(1, grupoMilitar.getNome());
            stmt.executeUpdate();

        }catch(SQLException ex){
            Logger.getLogger(ConflitosBelicosDAO.class.getName()).log(Level.SEVERE, null, ex);

        } finally{
            con.FecharConexao();

        }

    }
}
