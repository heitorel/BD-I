package com.bd.epbd.bean;

public class ChefeMilitar {

    public String id;
    public String hierarquia;
    public Integer idDivisao;
    public String nomeLiderPolitico;

    public ChefeMilitar() {
    }

    public ChefeMilitar(String id, String hierarquia, Integer idDivisao, String nomeLiderPolitico) {
        this.id = id;
        this.hierarquia = hierarquia;
        this.idDivisao = idDivisao;
        this.nomeLiderPolitico = nomeLiderPolitico;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getHierarquia() {
        return hierarquia;
    }

    public void setHierarquia(String hierarquia) {
        this.hierarquia = hierarquia;
    }

    public Integer getIdDivisao() {
        return idDivisao;
    }

    public void setIdDivisao(Integer idDivisao) {
        this.idDivisao = idDivisao;
    }

    public String getNomeLiderPolitico() {
        return nomeLiderPolitico;
    }

    public void setNomeLiderPolitico(String nomeLiderPolitico) {
        this.nomeLiderPolitico = nomeLiderPolitico;
    }
}
