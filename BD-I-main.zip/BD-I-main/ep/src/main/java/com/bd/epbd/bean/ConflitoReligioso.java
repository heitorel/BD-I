package com.bd.epbd.bean;

public class ConflitoReligioso {

    public Integer id;
    public String religioes;

    public ConflitoReligioso(Integer id, String religioes) {
        this.id = id;
        this.religioes = religioes;
    }

    public ConflitoReligioso() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getReligioes() {
        return religioes;
    }

    public void setReligioes(String religioes) {
        this.religioes = religioes;
    }
}
