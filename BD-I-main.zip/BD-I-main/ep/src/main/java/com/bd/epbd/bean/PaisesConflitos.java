package com.bd.epbd.bean;

public class PaisesConflitos {

    public String nome;
    public Integer quantidade;

    public PaisesConflitos(String nome, Integer quantidade) {
        this.nome = nome;
        this.quantidade = quantidade;
    }

    public PaisesConflitos() {
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(Integer quantidade) {
        this.quantidade = quantidade;
    }

    @Override
    public String toString() {
        return "PaisesConflitos{" +
                "nome='" + nome + '\'' +
                ", quantidade=" + quantidade +
                '}';
    }
}
