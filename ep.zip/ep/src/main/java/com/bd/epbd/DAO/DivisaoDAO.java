package com.bd.epbd.DAO;

import com.bd.epbd.ConexaoMySQL;
import com.bd.epbd.bean.Divisao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DivisaoDAO {

    public DivisaoDAO() {
    }

    ConexaoMySQL con = new ConexaoMySQL();

    public void CadastraDivisao(String id, Integer baixas, Integer barcos, Integer homens, Integer tanques, Integer avioes, Integer idGrupoArmado, Integer idChefeMilitar) throws SQLException, ClassNotFoundException{

        Connection connection = con.getConnection();

        PreparedStatement stmt = null;

        Divisao divisao = new Divisao(id,baixas,barcos,homens,tanques,avioes,idGrupoArmado,idChefeMilitar);

        try{
            stmt = connection.prepareStatement("INSERT INTO DIVISAO VALUES (?,?,?,?,?,?,?,?)");

            // O método setString, define que o valor passado será do tipo inteiro
            stmt.setString(1, divisao.getId());
            stmt.executeUpdate();

        }catch(SQLException ex){
            Logger.getLogger(ConflitosBelicosDAO.class.getName()).log(Level.SEVERE, null, ex);

        } finally{
            con.FecharConexao();

        }

    }

}
