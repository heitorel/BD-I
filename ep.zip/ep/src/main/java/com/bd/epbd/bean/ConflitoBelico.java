package com.bd.epbd.bean;

public class ConflitoBelico {

    private String id;
    private String nome;
    private Integer mortos;
    private Integer feridos;
    private String tipo;
    private Integer idGrupo;

    public ConflitoBelico() {
    }

    public ConflitoBelico(String id, String nome, Integer mortos, Integer feridos, String tipo, Integer idGrupo) {
        this.id = id;
        this.nome = nome;
        this.mortos = mortos;
        this.feridos = feridos;
        this.tipo = tipo;
        this.idGrupo = idGrupo;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getMortos() {
        return mortos;
    }

    public void setMortos(Integer mortos) {
        this.mortos = mortos;
    }

    public Integer getFeridos() {
        return feridos;
    }

    public void setFeridos(Integer feridos) {
        this.feridos = feridos;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Integer getIdGrupo() {
        return idGrupo;
    }

    public void setIdGrupo(Integer idGrupo) {
        this.idGrupo = idGrupo;
    }

    @Override
    public String toString() {
        return "ConflitoBelico{" +
                "id=" + id +
                ", nome='" + nome + '\'' +
                ", mortos=" + mortos +
                ", feridos=" + feridos +
                ", tipo='" + tipo + '\'' +
                ", idGrupo=" + idGrupo +
                '}';
    }
}
