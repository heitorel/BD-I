package com.bd.epbd.bean;

public class ConflitoTerritorial {

    public Integer id;
    public String regioes;

    public ConflitoTerritorial(Integer id, String regioes) {
        this.id = id;
        this.regioes = regioes;
    }

    public ConflitoTerritorial() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getRegioes() {
        return regioes;
    }

    public void setRegioes(String regioes) {
        this.regioes = regioes;
    }
}
