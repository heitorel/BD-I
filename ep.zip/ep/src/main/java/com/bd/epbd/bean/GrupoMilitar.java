package com.bd.epbd.bean;

import java.util.Date;

public class GrupoMilitar {

    public String id;
    public String conflitos;
    public String nome;
    public Date dataSaida;
    public Date dataEntrada;

    public GrupoMilitar(String id, String conflitos, String nome, Date dataSaida, Date dataEntrada) {
        this.id = id;
        this.conflitos = conflitos;
        this.nome = nome;
        this.dataSaida = dataSaida;
        this.dataEntrada = dataEntrada;
    }

    public GrupoMilitar() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getConflitos() {
        return conflitos;
    }

    public void setConflitos(String conflitos) {
        this.conflitos = conflitos;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Date getDataSaida() {
        return dataSaida;
    }

    public void setDataSaida(Date dataSaida) {
        this.dataSaida = dataSaida;
    }

    public Date getDataEntrada() {
        return dataEntrada;
    }

    public void setDataEntrada(Date dataEntrada) {
        this.dataEntrada = dataEntrada;
    }
}
